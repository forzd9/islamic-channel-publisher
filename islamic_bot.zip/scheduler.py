from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from aiogram import Bot
from database import get_session, Job
from services.publishing_service import PublishingService
from logger import logger
from typing import Dict

class SchedulerService:
    def __init__(self, bot: Bot):
        self.bot = bot
        self.scheduler = AsyncIOScheduler(timezone="UTC")
        self.scheduler.start()
        self.jobs: Dict[str, str] = {}

    def add_job(self, job: Job):
        if job.name in self.jobs:
            self.scheduler.remove_job(self.jobs[job.name])
        trigger = IntervalTrigger(seconds=job.interval)
        job_id = self.scheduler.add_job(
            self._publish_job,
            trigger=trigger,
            args=[job.id],
            id=job.name,
            replace_existing=True
        ).id
        self.jobs[job.name] = job_id
        logger.info(f"Added job {job.name} with interval {job.interval}s")

    def remove_job(self, job_name: str):
        if job_name in self.jobs:
            self.scheduler.remove_job(self.jobs[job_name])
            del self.jobs[job_name]
            logger.info(f"Removed job {job_name}")

    def start(self):
        if not self.scheduler.running:
            self.scheduler.start()
            logger.info("Scheduler started")

    def stop(self):
        if self.scheduler.running:
            self.scheduler.shutdown(wait=False)
            logger.info("Scheduler stopped")

    async def _publish_job(self, job_id: int):
        async with get_session() as session:
            job = await session.get(Job, job_id)
            if not job or not job.enabled:
                return
            pub_service = PublishingService(self.bot)
            content = None
            import random
            content_type = random.choice(job.content_types)
            if content_type == "quran":
                content = await pub_service.compose_quran_post()
            elif content_type == "hadith":
                content = await pub_service.compose_hadith_post()
            elif content_type == "adhkar":
                content = await pub_service.compose_adhkar_post()
            if not content:
                logger.error(f"Failed to generate content for job {job.name}")
                return
            for chat_id in job.target_channels:
                await pub_service.publish_to_channel(chat_id, content)
            logger.info(f"Job {job.name} executed, sent to {len(job.target_channels)} channels")

    async def load_jobs_from_db(self):
        async with get_session() as session:
            jobs = await session.execute(Job.__table__.select().where(Job.enabled == True))
            jobs = jobs.all()
            for job in jobs:
                self.add_job(job)

scheduler_service = None
