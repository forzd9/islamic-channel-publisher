from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import List

def main_admin_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="▶️ Start Publishing", callback_data="admin:start"),
        InlineKeyboardButton(text="⏹️ Stop Publishing", callback_data="admin:stop")
    )
    builder.row(
        InlineKeyboardButton(text="⏱ Schedule", callback_data="admin:schedule"),
        InlineKeyboardButton(text="🎙 Reciter", callback_data="admin:reciter")
    )
    builder.row(
        InlineKeyboardButton(text="📜 Font Style", callback_data="admin:font"),
        InlineKeyboardButton(text="➕ Add Channel", callback_data="admin:add_channel")
    )
    builder.row(
        InlineKeyboardButton(text="📊 Statistics", callback_data="admin:stats"),
        InlineKeyboardButton(text="📤 Manual Post", callback_data="admin:manual")
    )
    builder.row(
        InlineKeyboardButton(text="⚙️ Settings", callback_data="admin:settings"),
        InlineKeyboardButton(text="❌ Close", callback_data="admin:close")
    )
    return builder.as_markup()

def schedule_keyboard(jobs: List[dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for job in jobs:
        status = "✅" if job["enabled"] else "❌"
        builder.row(
            InlineKeyboardButton(
                text=f"{status} {job['name']} ({job['interval']}s)",
                callback_data=f"admin:job:{job['id']}"
            )
        )
    builder.row(
        InlineKeyboardButton(text="➕ New Job", callback_data="admin:new_job"),
        InlineKeyboardButton(text="🔙 Back", callback_data="admin:back")
    )
    return builder.as_markup()

def reciter_keyboard() -> InlineKeyboardMarkup:
    from config import RECITERS
    builder = InlineKeyboardBuilder()
    for rec_id, name in RECITERS.items():
        builder.row(InlineKeyboardButton(text=name, callback_data=f"admin:set_reciter:{rec_id}"))
    builder.row(InlineKeyboardButton(text="🔙 Back", callback_data="admin:back"))
    return builder.as_markup()

def font_style_keyboard() -> InlineKeyboardMarkup:
    from config import FONT_STYLES
    builder = InlineKeyboardBuilder()
    for style in FONT_STYLES.keys():
        builder.row(InlineKeyboardButton(text=style.capitalize(), callback_data=f"admin:set_font:{style}"))
    builder.row(InlineKeyboardButton(text="🔙 Back", callback_data="admin:back"))
    return builder.as_markup()

def channels_keyboard(channels: List[dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for ch in channels:
        title = ch["title"][:20] + "..." if len(ch["title"]) > 20 else ch["title"]
        builder.row(InlineKeyboardButton(text=f"❌ {title}", callback_data=f"admin:del_channel:{ch['chat_id']}"))
    builder.row(InlineKeyboardButton(text="➕ Add via ID", callback_data="admin:prompt_channel_id"))
    builder.row(InlineKeyboardButton(text="🔙 Back", callback_data="admin:back"))
    return builder.as_markup()

def back_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🔙 Back", callback_data="admin:back"))
    return builder.as_markup()
