from aiogram import Bot
from services.quran_service import quran_service
from services.hadith_service import hadith_service
from services.adhkar_service import adhkar_service
from utils.fonts import apply_font_style
from utils.formatting import split_long_message
from database import get_session, Setting, Stat
from logger import logger
import random
from datetime import datetime
from sqlalchemy import func

class PublishingService:
    def __init__(self, bot: Bot):
        self.bot = bot

    async def compose_quran_post(self) -> dict:
        surah, verse = await quran_service.random_verse()
        verse_data = await quran_service.get_verse(surah, verse)
        if not verse_data:
            return None
        tafsir = await quran_service.get_tafsir(surah, verse)
        reciter_id = await self._get_setting("reciter", "ar.alafasy")
        audio_url = await quran_service.get_audio(surah, verse, reciter_id)
        surah_name = verse_data["surah"]["englishName"]
        verse_text = verse_data["text"]
        font_style = await self._get_setting("font_style", "default")
        verse_text = apply_font_style(verse_text, font_style)
        lines = [
            f"📖 *Surah {surah_name} — Verse {verse}*",
            "",
            verse_text,
            ""
        ]
        if audio_url:
            lines.append(f"🎧 *Reciter:* {self._reciter_name(reciter_id)}")
            lines.append("")
        if tafsir:
            lines.append(f"📜 *Tafsir:*")
            lines.append(tafsir)
            lines.append("")
        if random.choice([True, False]):
            hadith = await hadith_service.random_hadith()
            if hadith:
                lines.append(f"📚 *Related Hadith*")
                lines.append(hadith["arabic"])
                lines.append("")
        text = "\n".join(lines)
        return {
            "text": text,
            "audio": audio_url,
            "type": "quran"
        }

    async def compose_hadith_post(self) -> dict:
        hadith = await hadith_service.random_hadith()
        if not hadith:
            return None
        text = f"📚 *Hadith*\n\n{hadith['arabic']}"
        return {"text": text, "type": "hadith"}

    async def compose_adhkar_post(self) -> dict:
        dhikr = await adhkar_service.random_adkhar()
        if not dhikr:
            return None
        text = f"🕋 *{dhikr.get('title', 'ذكر')}*\n\n{dhikr.get('arabic', '')}"
        if dhikr.get('translation'):
            text += f"\n\n_{dhikr['translation']}_"
        return {"text": text, "type": "adhkar"}

    async def publish_to_channel(self, chat_id: int, content: dict):
        try:
            if content.get("audio"):
                await self.bot.send_message(chat_id, content["text"], parse_mode="Markdown")
                await self.bot.send_audio(chat_id, content["audio"])
            else:
                parts = split_long_message(content["text"])
                for part in parts:
                    await self.bot.send_message(chat_id, part, parse_mode="Markdown")
            await self._increment_stat()
        except Exception as e:
            logger.error(f"Failed to publish to {chat_id}: {e}")

    async def _get_setting(self, key: str, default=None):
        async with get_session() as session:
            setting = await session.get(Setting, key)
            if setting:
                return setting.value
        return default

    async def _set_setting(self, key: str, value):
        async with get_session() as session:
            setting = await session.get(Setting, key)
            if setting:
                setting.value = value
            else:
                setting = Setting(key=key, value=value)
                session.add(setting)
            await session.commit()

    def _reciter_name(self, reciter_id: str) -> str:
        from config import RECITERS
        return RECITERS.get(reciter_id, reciter_id)

    async def _increment_stat(self):
        async with get_session() as session:
            today = datetime.now().date()
            stat = await session.execute(
                Stat.__table__.select().where(func.date(Stat.date) == today)
            )
            stat = stat.scalar_one_or_none()
            if stat:
                stat.posts_sent += 1
            else:
                stat = Stat(posts_sent=1)
                session.add(stat)
            await session.commit()
