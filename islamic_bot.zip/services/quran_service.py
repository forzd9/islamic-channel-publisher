import aiohttp
from typing import Optional, Tuple
from config import QURAN_API_BASE
from utils.api_retry import api_retry
from cache import cache
from logger import logger

class QuranService:
    def __init__(self):
        self.base_url = QURAN_API_BASE

    @api_retry
    async def get_verse(self, surah: int, verse: int, edition: str = "quran-uthmani") -> Optional[dict]:
        cache_key = f"verse:{surah}:{verse}:{edition}"
        cached = await cache.get(cache_key)
        if cached:
            return cached
        url = f"{self.base_url}/ayah/{surah}:{verse}/{edition}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    result = data["data"]
                    await cache.set(cache_key, result)
                    return result
                else:
                    logger.error(f"Quran API error {resp.status}: {await resp.text()}")
                    return None

    @api_retry
    async def get_tafsir(self, surah: int, verse: int, edition: str = "ar.muyassar") -> Optional[str]:
        cache_key = f"tafsir:{surah}:{verse}:{edition}"
        cached = await cache.get(cache_key)
        if cached:
            return cached
        url = f"{self.base_url}/ayah/{surah}:{verse}/{edition}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    text = data["data"]["text"]
                    await cache.set(cache_key, text)
                    return text
                else:
                    logger.error(f"Tafsir API error {resp.status}: {await resp.text()}")
                    return None

    @api_retry
    async def get_audio(self, surah: int, verse: int, reciter: str = "ar.alafasy") -> Optional[str]:
        cache_key = f"audio:{surah}:{verse}:{reciter}"
        cached = await cache.get(cache_key)
        if cached:
            return cached
        url = f"{self.base_url}/ayah/{surah}:{verse}/{reciter}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    audio_url = data["data"]["audio"]
                    await cache.set(cache_key, audio_url)
                    return audio_url
                else:
                    logger.error(f"Audio API error {resp.status}: {await resp.text()}")
                    return None

    async def random_verse(self) -> Tuple[int, int]:
        import random
        surah = random.randint(1, 114)
        verse = random.randint(1, 300)
        return surah, verse

quran_service = QuranService()
