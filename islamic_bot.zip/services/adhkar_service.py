import aiohttp
import json
from typing import Optional
from utils.api_retry import api_retry
from cache import cache
from logger import logger

class AdhkarService:
    def __init__(self):
        self.api_base = "https://www.hisnmuslim.com/api"
        self.local_file = "data/adhkar.json"

    async def _load_local(self) -> list:
        try:
            with open(self.local_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get("adhkar", [])
        except Exception as e:
            logger.error(f"Failed to load local adhkar: {e}")
            return []

    @api_retry
    async def random_adkhar(self) -> Optional[dict]:
        cache_key = "adhkar:random"
        cached = await cache.get(cache_key)
        if cached:
            return cached
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{self.api_base}/ar/01.json") as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("content"):
                            import random
                            item = random.choice(data["content"])
                            result = {
                                "title": item.get("title", ""),
                                "arabic": item.get("arabic", ""),
                                "translation": item.get("translation", "")
                            }
                            await cache.set(cache_key, result)
                            return result
        except Exception as e:
            logger.warning(f"Adhkar API failed, using local: {e}")
        local_data = await self._load_local()
        if local_data:
            import random
            return random.choice(local_data)
        return None

adhkar_service = AdhkarService()
