import aiohttp
from typing import Optional
from utils.api_retry import api_retry
from cache import cache
from logger import logger

class HadithService:
    def __init__(self):
        self.base_url = "https://api.hadith.gading.dev"

    @api_retry
    async def random_hadith(self, book: str = "bukhari") -> Optional[dict]:
        cache_key = f"hadith:random:{book}"
        cached = await cache.get(cache_key)
        if cached:
            return cached
        import random
        start = random.randint(1, 7000)
        end = start + 1
        url = f"{self.base_url}/books/{book}/{start}-{end}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if data["data"] and data["data"]["hadiths"]:
                        hadith = data["data"]["hadiths"][0]
                        result = {
                            "number": hadith["number"],
                            "arabic": hadith["arabic"],
                            "id": hadith["id"]
                        }
                        await cache.set(cache_key, result)
                        return result
                logger.error(f"Hadith API error {resp.status}: {await resp.text()}")
                return None

hadith_service = HadithService()
