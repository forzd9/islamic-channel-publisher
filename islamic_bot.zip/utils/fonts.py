from config import FONT_STYLES

def apply_font_style(text: str, style: str = "default") -> str:
    template = FONT_STYLES.get(style, FONT_STYLES["default"])
    return template.format(text=text)
