import random
import string
from typing import List

def generate_id(length: int = 8) -> str:
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def chunk_list(lst: List, size: int):
    for i in range(0, len(lst), size):
        yield lst[i:i + size]
