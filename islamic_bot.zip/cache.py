import asyncio
import time
from typing import Any, Optional
from config import CACHE_TTL

class TTLCache:
    def __init__(self, ttl: int = CACHE_TTL):
        self._cache = {}
        self._ttl = ttl
        self._lock = asyncio.Lock()

    async def get(self, key: str) -> Optional[Any]:
        async with self._lock:
            if key in self._cache:
                value, expiry = self._cache[key]
                if expiry > time.time():
                    return value
                else:
                    del self._cache[key]
        return None

    async def set(self, key: str, value: Any):
        async with self._lock:
            self._cache[key] = (value, time.time() + self._ttl)

    async def delete(self, key: str):
        async with self._lock:
            self._cache.pop(key, None)

    async def clear(self):
        async with self._lock:
            self._cache.clear()

cache = TTLCache()
