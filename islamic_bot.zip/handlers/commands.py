from aiogram import Router, types
from aiogram.filters import Command
from aiogram.types import Message
from config import ADMIN_IDS
from keyboards.admin_keyboards import main_admin_keyboard
from logger import logger
from database import get_session, User

router = Router()

@router.message(Command("start"))
async def cmd_start(message: Message):
    user = message.from_user
    async with get_session() as session:
        db_user = await session.get(User, user.id)
        if not db_user:
            db_user = User(user_id=user.id, username=user.username, first_name=user.first_name)
            session.add(db_user)
            await session.commit()
    await message.answer(
        f"👋 Assalamu Alaikum {user.first_name}!\n"
        "I am an Islamic bot that publishes Quran, hadith, and adhkar.\n"
        "Use /admin to access the control panel (admins only)."
    )

@router.message(Command("help"))
async def cmd_help(message: Message):
    help_text = (
        "📖 *Islamic Bot Help*\n\n"
        "Commands:\n"
        "/start - Welcome message\n"
        "/help - This help\n"
        "/admin - Admin panel (restricted)\n\n"
        "The bot automatically publishes Islamic content to configured channels."
    )
    await message.answer(help_text, parse_mode="Markdown")

@router.message(Command("admin"))
async def cmd_admin(message: Message):
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("⛔ You are not authorized.")
        return
    await message.answer(
        "🕋 *Admin Control Panel*\nChoose an option:",
        reply_markup=main_admin_keyboard(),
        parse_mode="Markdown"
    )
