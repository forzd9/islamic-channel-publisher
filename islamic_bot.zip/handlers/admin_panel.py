from aiogram import Router, F, types
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from config import ADMIN_IDS, RECITERS, FONT_STYLES
from keyboards.admin_keyboards import (
    main_admin_keyboard, schedule_keyboard, reciter_keyboard,
    font_style_keyboard, channels_keyboard, back_keyboard
)
from database import get_session, Channel, Job, Setting, Stat
from scheduler import scheduler_service
from services.publishing_service import PublishingService
from logger import logger
from datetime import datetime
from sqlalchemy import func

router = Router()

class AdminStates(StatesGroup):
    waiting_channel_id = State()
    waiting_new_job_name = State()
    waiting_new_job_interval = State()
    waiting_new_job_content = State()
    waiting_manual_content = State()

@router.callback_query(F.data == "admin:start")
async def start_publishing(callback: CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Unauthorized", show_alert=True)
        return
    scheduler_service.start()
    await callback.answer("Publishing started!")
    await callback.message.edit_text("✅ Automatic publishing has been started.", reply_markup=back_keyboard())

@router.callback_query(F.data == "admin:stop")
async def stop_publishing(callback: CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Unauthorized", show_alert=True)
        return
    scheduler_service.stop()
    await callback.answer("Publishing stopped!")
    await callback.message.edit_text("⏹️ Automatic publishing has been stopped.", reply_markup=back_keyboard())

@router.callback_query(F.data == "admin:schedule")
async def show_schedule(callback: CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Unauthorized", show_alert=True)
        return
    async with get_session() as session:
        jobs = await session.execute(Job.__table__.select())
        jobs = jobs.all()
        job_list = [{"id": j.id, "name": j.name, "interval": j.interval, "enabled": j.enabled} for j in jobs]
    await callback.message.edit_text(
        "⏱ *Job Scheduler*\nManage your publishing jobs:",
        reply_markup=schedule_keyboard(job_list),
        parse_mode="Markdown"
    )

@router.callback_query(F.data.startswith("admin:job:"))
async def job_detail(callback: CallbackQuery):
    job_id = int(callback.data.split(":")[-1])
    async with get_session() as session:
        job = await session.get(Job, job_id)
        if not job:
            await callback.answer("Job not found")
            return
        text = f"📌 *Job: {job.name}*\n"
        text += f"Interval: {job.interval} seconds\n"
        text += f"Enabled: {'✅' if job.enabled else '❌'}\n"
        text += f"Content: {', '.join(job.content_types)}\n"
        text += f"Target channels: {len(job.target_channels)} channel(s)"
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="Toggle Enable", callback_data=f"admin:toggle_job:{job_id}"),
        InlineKeyboardButton(text="Delete", callback_data=f"admin:delete_job:{job_id}")
    )
    builder.row(InlineKeyboardButton(text="🔙 Back", callback_data="admin:schedule"))
    await callback.message.edit_text(text, reply_markup=builder.as_markup(), parse_mode="Markdown")

@router.callback_query(F.data.startswith("admin:toggle_job:"))
async def toggle_job(callback: CallbackQuery):
    job_id = int(callback.data.split(":")[-1])
    async with get_session() as session:
        job = await session.get(Job, job_id)
        if job:
            job.enabled = not job.enabled
            await session.commit()
            if job.enabled:
                scheduler_service.add_job(job)
            else:
                scheduler_service.remove_job(job.name)
    await callback.answer("Job toggled")
    await show_schedule(callback)

@router.callback_query(F.data.startswith("admin:delete_job:"))
async def delete_job(callback: CallbackQuery):
    job_id = int(callback.data.split(":")[-1])
    async with get_session() as session:
        job = await session.get(Job, job_id)
        if job:
            scheduler_service.remove_job(job.name)
            await session.delete(job)
            await session.commit()
    await callback.answer("Job deleted")
    await show_schedule(callback)

@router.callback_query(F.data == "admin:new_job")
async def new_job_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text("Enter a name for the new job:")
    await state.set_state(AdminStates.waiting_new_job_name)

@router.message(AdminStates.waiting_new_job_name)
async def new_job_name(message: Message, state: FSMContext):
    await state.update_data(job_name=message.text)
    await message.answer("Enter interval in seconds (e.g., 3600 for 1 hour):")
    await state.set_state(AdminStates.waiting_new_job_interval)

@router.message(AdminStates.waiting_new_job_interval)
async def new_job_interval(message: Message, state: FSMContext):
    try:
        interval = int(message.text)
        if interval <= 0:
            raise ValueError
    except:
        await message.answer("Invalid number. Please enter a positive integer.")
        return
    await state.update_data(job_interval=interval)
    await message.answer(
        "Enter content types (comma separated): quran, hadith, adhkar\n"
        "Example: quran, hadith"
    )
    await state.set_state(AdminStates.waiting_new_job_content)

@router.message(AdminStates.waiting_new_job_content)
async def new_job_content(message: Message, state: FSMContext):
    types = [t.strip() for t in message.text.split(",")]
    valid = {"quran", "hadith", "adhkar"}
    if not all(t in valid for t in types):
        await message.answer("Invalid types. Please use only: quran, hadith, adhkar")
        return
    data = await state.get_data()
    async with get_session() as session:
        channels = await session.execute(Channel.__table__.select())
        channels = channels.all()
        target_chats = [c.chat_id for c in channels]
    async with get_session() as session:
        job = Job(
            name=data["job_name"],
            interval=data["job_interval"],
            content_types=types,
            target_channels=target_chats,
            enabled=True
        )
        session.add(job)
        await session.commit()
        scheduler_service.add_job(job)
    await state.clear()
    await message.answer(f"✅ Job '{data['job_name']}' created.", reply_markup=back_keyboard())

@router.callback_query(F.data == "admin:reciter")
async def choose_reciter(callback: CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Unauthorized")
        return
    await callback.message.edit_text(
        "Select a reciter:",
        reply_markup=reciter_keyboard()
    )

@router.callback_query(F.data.startswith("admin:set_reciter:"))
async def set_reciter(callback: CallbackQuery):
    reciter_id = callback.data.split(":")[-1]
    async with get_session() as session:
        setting = await session.get(Setting, "reciter")
        if setting:
            setting.value = reciter_id
        else:
            setting = Setting(key="reciter", value=reciter_id)
            session.add(setting)
        await session.commit()
    await callback.answer(f"Reciter set to {RECITERS.get(reciter_id, reciter_id)}")
    await callback.message.edit_text("✅ Reciter updated.", reply_markup=back_keyboard())

@router.callback_query(F.data == "admin:font")
async def choose_font(callback: CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Unauthorized")
        return
    await callback.message.edit_text(
        "Select font style:",
        reply_markup=font_style_keyboard()
    )

@router.callback_query(F.data.startswith("admin:set_font:"))
async def set_font(callback: CallbackQuery):
    style = callback.data.split(":")[-1]
    async with get_session() as session:
        setting = await session.get(Setting, "font_style")
        if setting:
            setting.value = style
        else:
            setting = Setting(key="font_style", value=style)
            session.add(setting)
        await session.commit()
    await callback.answer(f"Font style set to {style}")
    await callback.message.edit_text("✅ Font style updated.", reply_markup=back_keyboard())

@router.callback_query(F.data == "admin:add_channel")
async def add_channel_menu(callback: CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Unauthorized")
        return
    async with get_session() as session:
        channels = await session.execute(Channel.__table__.select())
        channels = channels.all()
        channel_list = [{"chat_id": c.chat_id, "title": c.title or "Unknown"} for c in channels]
    await callback.message.edit_text(
        "Manage channels:",
        reply_markup=channels_keyboard(channel_list)
    )

@router.callback_query(F.data == "admin:prompt_channel_id")
async def prompt_channel_id(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text("Please send me the channel ID (e.g., -1001234567890):")
    await state.set_state(AdminStates.waiting_channel_id)

@router.message(AdminStates.waiting_channel_id)
async def add_channel_by_id(message: Message, state: FSMContext):
    try:
        chat_id = int(message.text)
    except:
        await message.answer("Invalid ID. Please send a numeric ID.")
        return
    try:
        chat = await message.bot.get_chat(chat_id)
        if chat.type not in ["channel", "supergroup"]:
            await message.answer("That is not a channel or group.")
            return
        member = await message.bot.get_chat_member(chat_id, (await message.bot.me()).id)
        if member.status not in ["administrator", "creator"]:
            await message.answer("Bot is not an admin in that channel.")
            return
    except Exception as e:
        await message.answer(f"Cannot access channel: {e}")
        return
    async with get_session() as session:
        existing = await session.get(Channel, chat_id)
        if existing:
            await message.answer("Channel already added.")
        else:
            channel = Channel(
                chat_id=chat_id,
                title=chat.title,
                is_group=(chat.type == "supergroup")
            )
            session.add(channel)
            await session.commit()
            await message.answer(f"✅ Channel '{chat.title}' added.")
    await state.clear()

@router.callback_query(F.data.startswith("admin:del_channel:"))
async def delete_channel(callback: CallbackQuery):
    chat_id = int(callback.data.split(":")[-1])
    async with get_session() as session:
        channel = await session.get(Channel, chat_id)
        if channel:
            await session.delete(channel)
            await session.commit()
            await callback.answer("Channel removed")
    await add_channel_menu(callback)

@router.callback_query(F.data == "admin:stats")
async def show_stats(callback: CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Unauthorized")
        return
    async with get_session() as session:
        today = datetime.now().date()
        total_posts = await session.execute(
            Stat.__table__.select().where(func.date(Stat.date) == today)
        )
        total_posts = total_posts.scalar_one_or_none()
        total_posts = total_posts.posts_sent if total_posts else 0
        channels_count = await session.execute(Channel.__table__.select().with_only_columns(func.count()))
        channels_count = channels_count.scalar()
        jobs_count = await session.execute(Job.__table__.select().with_only_columns(func.count()))
        jobs_count = jobs_count.scalar()
    text = (
        f"📊 *Statistics*\n\n"
        f"Posts today: {total_posts}\n"
        f"Channels: {channels_count}\n"
        f"Jobs: {jobs_count}\n"
    )
    await callback.message.edit_text(text, reply_markup=back_keyboard(), parse_mode="Markdown")

@router.callback_query(F.data == "admin:manual")
async def manual_post_menu(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Unauthorized")
        return
    await callback.message.edit_text(
        "Send me the content you want to publish manually.\n"
        "You can also use /cancel to abort."
    )
    await state.set_state(AdminStates.waiting_manual_content)

@router.message(AdminStates.waiting_manual_content)
async def handle_manual_post(message: Message, state: FSMContext, bot):
    content = message.text
    async with get_session() as session:
        channels = await session.execute(Channel.__table__.select())
        channels = channels.all()
    pub_service = PublishingService(bot)
    for ch in channels:
        await pub_service.publish_to_channel(ch.chat_id, {"text": content, "type": "manual"})
    await message.answer("✅ Manual post sent to all channels.")
    await state.clear()

@router.callback_query(F.data == "admin:settings")
async def show_settings(callback: CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Unauthorized")
        return
    async with get_session() as session:
        reciter_setting = await session.get(Setting, "reciter")
        reciter = reciter_setting.value if reciter_setting else "ar.alafasy"
        font_setting = await session.get(Setting, "font_style")
        font = font_setting.value if font_setting else "default"
    text = (
        f"⚙️ *Current Settings*\n\n"
        f"Reciter: {RECITERS.get(reciter, reciter)}\n"
        f"Font style: {font}\n"
    )
    await callback.message.edit_text(text, reply_markup=back_keyboard(), parse_mode="Markdown")

@router.callback_query(F.data == "admin:back")
async def back_to_main(callback: CallbackQuery):
    await callback.message.edit_text(
        "🕋 *Admin Control Panel*",
        reply_markup=main_admin_keyboard(),
        parse_mode="Markdown"
    )

@router.callback_query(F.data == "admin:close")
async def close_panel(callback: CallbackQuery):
    await callback.message.delete()
