#!/usr/bin/env python3
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from config import BOT_TOKEN
from logger import logger
from database import init_db
from handlers import commands, admin_panel
from scheduler import SchedulerService, scheduler_service as global_scheduler
import sys

async def main():
    logger.info("Starting Islamic Bot...")
    await init_db()
    logger.info("Database initialized")

    bot = Bot(token=BOT_TOKEN)
    dp = Dispatcher(storage=MemoryStorage())

    dp.include_router(commands.router)
    dp.include_router(admin_panel.router)

    # Initialize scheduler
    scheduler = SchedulerService(bot)
    # Assign to global variable for access in handlers
    import scheduler as scheduler_module
    scheduler_module.scheduler_service = scheduler

    await scheduler.load_jobs_from_db()
    logger.info("Scheduler loaded")

    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()
        scheduler.stop()
        logger.info("Bot stopped")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        sys.exit(0)
