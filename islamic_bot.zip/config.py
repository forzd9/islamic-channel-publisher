import logging

BOT_TOKEN = "7370155559:AAF4jH4f7db_8QZYqoay_tWv1-CMXpCNgrY"
ADMIN_IDS = [6891530912]

QURAN_API_BASE = "https://api.alquran.cloud/v1"
HADITH_API_BASE = "https://api.hadith.gading.dev"
ADHKAR_API_BASE = "https://www.hisnmuslim.com/api"

RECITERS = {
    "ar.alafasy": "Mishary Alafasy",
    "ar.abdulsamad": "Abdul Samad",
    "ar.shaatree": "Abu Bakr Al-Shaatree",
    "ar.husary": "Mahmoud Khalil Al-Husary",
    "ar.ajamy": "Ahmad Al-Ajamy"
}

FONT_STYLES = {
    "default": "{text}",
    "brackets": "﴿ {text} ﴾",
    "six_pointed": "۞ {text} ۞",
    "fleuron": "❖ {text} ❖"
}

DEFAULT_INTERVAL = 3600
LOG_LEVEL = logging.INFO
LOG_FILE = "bot.log"
DATABASE_URL = "sqlite+aiosqlite:///bot.db"
CACHE_TTL = 300
